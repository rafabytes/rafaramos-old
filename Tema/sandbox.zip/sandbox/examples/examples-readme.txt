=== Sandbox Example Style Sheets ===

This folder contains the original Sandbox layouts and examples of other layouts. There is also a printer-friendly style sheet to serve as a starting point.

You can cut and paste these into your own style sheet, use them as references, or completely ignore them.