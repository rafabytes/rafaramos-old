=== Sandbox Translations ===

This folder contains the source files for the translations provided with the Sandbox. The sandbox.pot file included here should be used for generating your translations.

For more information on creating a Sandbox translation in your language, please visit

	http://code.google.com/p/sandbox-theme/wiki/SandboxInYourLanguage
